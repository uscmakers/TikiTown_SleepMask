#include "Arduino.h"
#include "ControlRGB.h"
#include <algorithm>

ControlRGB::ControlRGB() {
	_rPin = 3;
	_gPin = 5;
	_bPin = 6;
	pinMode(_rPin, OUTPUT);
	pinMode(_gPin, OUTPUT);
	pinMode(_bPin, OUTPUT);
	_rBrightness = 255;
	_gBrightness = 255;
	_bBrightness = 255;
}

ControlRGB::ControlRGB(int rPin, int gPin, int bPin, int rBrightness, int gBrightness, int bBrightness) {
	_rPin = rPin;
	_gPin = gPin;
	_bPin = bPin;
	pinMode(_rPin, OUTPUT);
	pinMode(_gPin, OUTPUT);
	pinMode(_bPin, OUTPUT);
	_rBrightness = rBrightness;
	_gBrightness = gBrightness;
	_bBrightness = bBrightness;
}

ControlRGB::turnOn(int delay) {
	int rCounter = 0;
	int gCounter = 0;
	int bCounter = 0;
	while (rCounter != _rBrightness && gCounter != _gBrightness && bCounter != _bBrightness) {
		analogWrite(_rPin, rCounter);
		analogWrite(_gPin, gCounter);
		analogWrite(_bPin, bCounter);
		rCounter += delay / _rBrightness;
		gCounter += delay / _gBrightness;
		bCounter += delay / _bBrightness;
	}
}

ControlRGB::turnOff() {
	digitalWrite(_rPin, 0);
	digitalWrite(_gPin, 0);
	digitalWrite(_bPin, 0);
}