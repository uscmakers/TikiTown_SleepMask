#ifndef ControlRGB_H
#define ControlRGB_H

#include "Arduino.h"

class ControlRGB
{
  public:
   	ControlRGB();
   	ControlRGB(int rPin, int gPin, int bPin, int rBrightness, int gBrightness, int bBrightness);
   	void turnOn(int delay); //delay in ms (delay is time to reach full brightness)
   	void turnOff();
  private:
    int _rPin;
    int _gPin;
    int _bPin;
    int _rBrightness;
    int _gBrightness;
    int _bBrightness;
};


#endif
